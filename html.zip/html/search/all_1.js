var searchData=
[
  ['rx_0',['rx',['../struct_pacote_joystick.html#a33fea3101984f9dca09bcdfd21cf086c',1,'PacoteJoystick']]],
  ['ry_1',['ry',['../struct_pacote_joystick.html#a92ecfb3af4426740f9ba367800d107c5',1,'PacoteJoystick']]]
];
