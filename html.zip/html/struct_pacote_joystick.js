var struct_pacote_joystick =
[
    [ "rx", "struct_pacote_joystick.html#a33fea3101984f9dca09bcdfd21cf086c", null ],
    [ "ry", "struct_pacote_joystick.html#a92ecfb3af4426740f9ba367800d107c5", null ]
];