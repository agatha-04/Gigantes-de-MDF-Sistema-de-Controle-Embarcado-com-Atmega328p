var NAVTREEINDEX0 =
{
"annotated.html":[0,0],
"classes.html":[0,1],
"functions.html":[0,2,0],
"functions_vars.html":[0,2,1],
"index.html":[],
"pages.html":[],
"struct_pacote_joystick.html":[0,0,0],
"struct_pacote_joystick.html#a33fea3101984f9dca09bcdfd21cf086c":[0,0,0,0],
"struct_pacote_joystick.html#a92ecfb3af4426740f9ba367800d107c5":[0,0,0,1]
};
