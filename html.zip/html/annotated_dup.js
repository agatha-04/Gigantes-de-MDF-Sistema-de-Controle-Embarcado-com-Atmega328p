var annotated_dup =
[
    [ "PacoteJoystick", "struct_pacote_joystick.html", "struct_pacote_joystick" ]
];